/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airlinereservation;

/**
 *
 * @author sree
 */
public interface departdate 


{
    public String depart_date = "",depart_time = "";
    
    // method to return the time
    public String return_date();
  
    
     // method to return the time
    public String return_time();
    
    
    
}
