/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airlinereservation;

import java.util.Scanner;

/**
 *
 * @author sree
 */
public class fares 

{

    public fares()
    {
        rate = 0;
        airline_name = "";
        itenary_id = "";
        
    }
    
    
    private double rate ;
    private String airline_name,itenary_id ;
    
    // insert new fare detail into DB
    public void insert_new_fare()
    {
        
        
                            Scanner input = new Scanner(System.in);
        
                            System.out.println("<<<<<<<< Welcome to the Airline reservation system >>>>>>>\n");
                            System.out.println("<<<<<<<<<<<<<<<<<<<<< Insert new Fare >>>>>>>>>>>>>>>>>>>>");
                            System.out.println("\n\n");
                           
                            System.out.println("Enter the itenary ID: ;");
                            this.itenary_id = input.nextLine();
                            
                            // search for itenary_id in DB. If exists, provide option to add new fare; else throw error itenary not found.
                            //*******************************************************************************************
                            
                            // code for DB search
                            
                            //*******************************************************************************************
                            
                            System.out.println("Enter new airline name: ;");
                            this.airline_name = input.nextLine();
                            
                            System.out.println("Enter the new fare rate :");
                            this.rate  = input.nextDouble();
                            
                            // code to insert data into DB.
                            //*******************************************************************************************
                            
                            
                            
                            //*******************************************************************************************
    }
    
    // method to retrieve the fares from DB.
    public void display_fare()
   
    {
                            // code to retrieve data from the DB and store in class variables.
                            //********************************************************************************
                                
        
                            
        
                            //********************************************************************************
        
                            // to put below code in loop until the end of rows in DB
                            System.out.print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                            System.out.print("Itenary_ID :" + this.itenary_id);
                            System.out.print("Airline name :" + this.airline_name);
                            System.out.print("Fare :" + this.rate);                           
                            System.out.print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
    }
    
    // method to return a fare.
    public double return_fare()
    {
        return this.rate;
    }
    
    // method to set a input fare 
      public void set_fare(double input_fare)
    {
        this.rate = input_fare;
    }
}
