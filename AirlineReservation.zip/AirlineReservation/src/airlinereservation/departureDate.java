/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airlinereservation;

/**
 *
 * @author sree
 */
public class departureDate 

{
     String date,time;

    public departureDate()    
    {
        date = "";
        time = "";
    }
    
    // method to retuen the date
    public String return_date()
    {
        return this.date;
        
    }
    
     // method to retuen the time
    public String return_time()
    {
        return this.time;
        
    }  
    
    
     
}
