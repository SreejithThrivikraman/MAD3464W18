/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airlinereservation;

import com.mysql.jdbc.Connection;

import java.sql.*;


/**
 *
 * @author sree
 */
public class DBConnection 

{
    private static final String USERNAME    = "root";
    private static final String PASSWORD    = " ";
    private static final String CONN_STRING = "jdbc:mysql://localhost/javatest";
    Connection conn = null;
    
    void connect ()
    {
        
        
        try 
        {
            conn =  (Connection) DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
            System.out.println("Connected !");
        } catch (SQLException e)
        {
            System.err.println("Connection error !");
        }
    }
}
