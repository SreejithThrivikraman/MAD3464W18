/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airlinereservation;

import java.util.Scanner;

/**
 *
 * @author sree
 */
public class itenary 

{
    
    public String startPoint,endPoint = "";
    public double airmiles = 0;
    public int itenaryID = 0;
    
    
    public void display_itenaries()        // getter method for itenary
    
    {                   
                            // code to retrieve data from the DB and store in class variables.
                            //********************************************************************************
                                
        
                            
        
                            //********************************************************************************
        
                            // to put below code in loop until the end of rows in DB
                            System.out.print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                            System.out.print("Destination :" + this.itenaryID);
                            System.out.print("Start Destination :" + this.startPoint);
                            System.out.print("Final Destination :" + this.endPoint);
                            System.out.print("Airmiles :" + this.airmiles);
                            System.out.print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                            
    }
    
    
    public void insert_new_itenary()        // setter method for itenary
    
    {
                            Scanner input = new Scanner(System.in);
        
                            System.out.println("<<<<<<<< Welcome to the Airline reservation system >>>>>>>\n");
                            System.out.println("<<<<<<<<<<<<<<<<<<<<< Insert new itenary >>>>>>>>>>>>>>>>>>");
                            System.out.println("\n\n");
                           
                            System.out.println("Enter new stating destination ;");
                            this.startPoint = input.nextLine();
                            
                            System.out.println("Enter new final destination ;");
                            this.endPoint = input.nextLine();
                            
                            System.out.println("Enter the total airmiles between destinations :");
                            this.airmiles = input.nextDouble();
                            
                            // code to insert data into DB.
                            //*******************************************************************************************
                            
                            
                            
                            //*******************************************************************************************
    }
    
        
    
}
