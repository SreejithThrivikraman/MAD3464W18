/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airlinereservation;

import java.util.Scanner;

/**
 *
 * @author sree
 */
public class AirlineReservation 

{

    public static void main(String[] args)
    {
        // TODO code application logic here
        
        
       // DBConnection object = new DBConnection();
       // object.connect();
        
        Scanner input = new Scanner(System.in);
        String user_name,password;
        int screen_choice = 0;
        Boolean flag = true;
        
        System.out.println("<<<<<<<< Welcome to the Airline reservation system >>>>>>>\n");
        System.out.println("<<<<<<<<<<<<<<<<<<<<<<<< Login >>>>>>>>>>>>>>>>>>>>>>>>>>>");
        
        System.out.println("Please enter your user name and password to continue.");
        System.out.println("User Name :");
        user_name = input.nextLine();
        
        System.out.println("Passowrd :");
        password = input.nextLine();
        
        // code to check the database user name and password. If matches, login to the main reservation screen else display error msg.
        //***************************************************************************************************************************
        
        
        
        //***************************************************************************************************************************
        
        System.out.println("Login successful !!! :");
        
        while (flag == true) {
            System.out.println("\n\n\n\n\n\n\n");
            System.out.println("<<<<<<<< Welcome to the Airline reservation system >>>>>>>\n");
            System.out.println("Choose the following operations to continue:\n");
            System.out.println("1. Make a reservation");
            System.out.println("2. Choose itenary");
            System.out.println("3. Flight Repository");
            System.out.println("4. Passenger List");
            System.out.println("5. Reservation Register");

            System.out.println("Option : ");
            screen_choice = input.nextInt();

            switch (screen_choice) {
                case 1: {
                            System.out.println("<<<<<<<< Welcome to the Airline reservation system >>>>>>>\n");
                            System.out.println("<<<<<<<<<<<<<<<<<< Make a Reservation >>>>>>>>>>>>>>>>>>>>");
                            flag = false;
                            break;
                            
                }

                case 2: {
                            System.out.println("<<<<<<<< Welcome to the Airline reservation system >>>>>>>\n");
                            System.out.println("<<<<<<<<<<<<<<<<<<<<< Choose itenary >>>>>>>>>>>>>>>>>>>>>");
                            flag = false;
                            break;
                }

                case 3: {
                            System.out.println("<<<<<<<< Welcome to the Airline reservation system >>>>>>>\n");
                            System.out.println("<<<<<<<<<<<<<<<<<<<<< Flight Repository >>>>>>>>>>>>>>>>>>");
                            flag = false;
                            break;
                }

                case 4: {
                            System.out.println("<<<<<<<< Welcome to the Airline reservation system >>>>>>>\n");
                            System.out.println("<<<<<<<<<<<<<<<<<<<<< Passenger List >>>>>>>>>>>>>>>>>>>>>");
                            flag = false;
                            break;
                }
                case 5: {
                            System.out.println("<<<<<<<< Welcome to the Airline reservation system >>>>>>>\n");
                            System.out.println("<<<<<<<<<<<<<<<<<<<<< Reservation Register >>>>>>>>>>>>>>>");
                            flag = false;
                            break;

                }

                default: {
                    System.out.println("invalid entry !!!! Try again !!");
                    break;
                }
            }

        }

    }
}